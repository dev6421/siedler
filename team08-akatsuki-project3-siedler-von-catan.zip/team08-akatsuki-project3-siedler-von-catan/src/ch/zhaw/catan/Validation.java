package ch.zhaw.catan;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class contains static methods to validate if a road, settlement or city can be placed.
 *
 * @author Akatsuki
 * @version 12.22
 */
public class Validation {
    /**
     * Validates the distance of two settlements to be at least two roads apart.
     *
     * @param board  the game board
     * @param corner the position of the corner to validate
     * @return true if it's valid, else false
     */
    public static boolean validDistance(SiedlerBoard board, Point corner) {
        return board.getNeighboursOfCorner(corner).isEmpty() && (board.getCorner(corner) == null);
    }

    /**
     * Validates that the settlement is not on an outer corner of the game board or next to at least two water fields.
     *
     * @param board  the game board
     * @param corner the position of the corner to validate
     * @return true if it's valid, else false
     */
    public static boolean validNoWater(SiedlerBoard board, Point corner) {
        boolean notNextToWater;
        int waterFieldCount = 0;
        List<Config.Land> neighbourFields = board.getFields(corner);
        for (Config.Land field : neighbourFields) {
            if (field == Config.Land.WATER) {
                waterFieldCount++;
            }
        }
        notNextToWater = waterFieldCount <= 2;
        boolean inBound = neighbourFields.size() == 3;
        return (notNextToWater && inBound);
    }

    /**
     * Validates the placement of a road if it's placed to the players' faction next road, if it's placed to the
     * players faction next settlement and if an edge is available.
     *
     * @param board     the game board
     * @param roadStart the start of the road as coordinate
     * @param roadEnd   the end of the road as coordinate
     * @param faction   the faction of the player
     * @return true if it's valid, else false
     */
    public static boolean validRoadPlacement(SiedlerBoard board, Point roadStart, Point roadEnd, Config.Faction faction) {
        boolean valid;
        try {
            boolean bordersOwnSettlement = (board.getCorner(roadStart) != null && board.getCorner(roadStart).getFaction().equals(faction)) || (board.getCorner(roadEnd) != null && board.getCorner(roadEnd).getFaction().equals(faction));
            boolean isFree = board.getEdge(roadStart, roadEnd) == null;
            List<Config.Faction> startNeighbouringEdges = getFactionsFromRoad(board.getAdjacentEdges(roadStart));
            List<Config.Faction> endNeighbouringEdges = getFactionsFromRoad(board.getAdjacentEdges(roadEnd));
            boolean hasOwnAdjacentEdge = startNeighbouringEdges.contains(faction) || endNeighbouringEdges.contains(faction);
            valid = isFree && (bordersOwnSettlement || hasOwnAdjacentEdge);
        } catch (IllegalArgumentException e) {
            valid = false;
        }
        return valid;
    }

    /**
     * Validates the placement of a city if it's a settlement of the players' faction.
     *
     * @param currentPlayer       the current player
     * @param settlementToUpgrade the settlement to upgrade
     * @return true if it's valid, else false
     */
    public static boolean validCityPlacement(Player currentPlayer, Point settlementToUpgrade) {
        boolean valid = false;
        for (Settlement settlement : currentPlayer.getSettlements()) {
            if (settlement instanceof Settlement && settlement.equals(settlementToUpgrade)) {
                valid = true;
            }
        }
        return valid;
    }

    /**
     * Validates if a settlement borders its own street.
     *
     * @param board   the game board
     * @param faction the players' faction
     * @param corner  the position of the corner to validate
     * @return true if it's valid, else false
     */
    public static boolean validOwnStreet(SiedlerBoard board, Config.Faction faction, Point corner) {
        List<Config.Faction> street = getFactionsFromRoad(board.getAdjacentEdges(corner));
        return street.contains(faction);
    }

    /**
     * Get the adjacent roads from faction.
     *
     * @param roads the list of roads
     * @return a list of the factions' road
     */
    public static List<Config.Faction> getFactionsFromRoad(List<Road> roads) {
        List<Config.Faction> roadsAsFactions = new ArrayList<>();
        for (Road road : roads) {
            roadsAsFactions.add(road.getFaction());
        }
        return roadsAsFactions;
    }
}
