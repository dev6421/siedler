package ch.zhaw.catan;

import java.awt.*;

/**
 * This subclass extends {@link Settlement}
 *
 * @author Akatsuki
 * @version 12.22
 */
public class City extends Settlement {
    /**
     * Initializes a city.
     *
     * @param faction the players' faction
     * @param corner the position of the corner
     */
    public City(Config.Faction faction, Point corner) {
        super(faction, corner);
    }
}
