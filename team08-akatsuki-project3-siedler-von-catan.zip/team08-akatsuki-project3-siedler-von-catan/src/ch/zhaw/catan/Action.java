package ch.zhaw.catan;

public enum Action {
    THROW_DICE("Throw two Dices"),
    BUILD_SETTLEMENT("Build Settlement " + ConfigHelper.getResourceReqAsString(Config.Structure.SETTLEMENT)),
    BUILD_ROAD("Build Road " + ConfigHelper.getResourceReqAsString(Config.Structure.ROAD)),
    BUILD_CITY("Build City " + ConfigHelper.getResourceReqAsString(Config.Structure.CITY)),
    TRADE_WITH_BANK("Trade with Bank (Exchange 4x of the same Resource from you for 1x of another Resource)"),
    END_TURN("End Turn"),
    QUIT_GAME("Abort the Game");

    private String text;

    Action(String text){
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
}
