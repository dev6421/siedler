package ch.zhaw.catan;

import ch.zhaw.catan.Config.Land;
import ch.zhaw.hexboard.HexBoard;

import java.awt.*;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class SiedlerBoard extends HexBoard<Land, Settlement, Road, Annotation> {

    /**
     * Executes the Superclass Constructor and calls setupBoard()
     */
    SiedlerBoard(){
        super();
        setupBoard();
    }

    private void setupBoard() {
        Map<Point, Land> fieldsWithRessource = Config.getStandardLandPlacement();
        for (Map.Entry<Point, Config.Land> field : fieldsWithRessource.entrySet()) {
            super.addField(field.getKey(), field.getValue());
        }
    }
}
