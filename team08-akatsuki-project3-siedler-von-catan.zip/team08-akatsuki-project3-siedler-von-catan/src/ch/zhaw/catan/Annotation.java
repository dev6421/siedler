package ch.zhaw.catan;

/**
 * Used to mark the Position of the Thief in SiedlerBoard
 */
public class Annotation implements java.lang.annotation.Annotation {
    private String value;

    public Annotation(String value) {
        this.value = value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }

    @Override
    public Class<? extends java.lang.annotation.Annotation> annotationType() {
        return null;
    }
}


