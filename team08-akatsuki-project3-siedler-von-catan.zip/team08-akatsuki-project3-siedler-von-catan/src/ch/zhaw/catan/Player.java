package ch.zhaw.catan;

import java.util.*;

/**
 * This class handles the players and their resources and turns.
 *
 * @author Akatsuki
 * @version 12.22
 */
public class Player {
    private final Config.Faction faction;
    private final int turnPosition;
    private int availableNumberOfRoads = Config.Structure.ROAD.getStockPerPlayer();
    private int availableNumberOfCities = Config.Structure.CITY.getStockPerPlayer();
    private int availableNumberOfSettlements = Config.Structure.SETTLEMENT.getStockPerPlayer();
    private List<Settlement> settlements = new ArrayList<>();
    private List<Road> roads = new ArrayList<>();
    private Map<Config.Resource, Integer> playerStock = new HashMap<>();

    /**
     * Initializes a player with a turn position.
     *
     * @param turnPosition the position the players' turn
     */
    public Player(int turnPosition) {
        this.faction = ConfigHelper.getFactionSequence().get(turnPosition);
        this.turnPosition = turnPosition;
        initResources();
    }

    /**
     * Initializes the basic resources to be 0.
     */
    public void initResources() {
        Config.Resource[] initResources = Config.Resource.values();
        for (Config.Resource initResource : initResources) {
            playerStock.put(initResource, 0);
        }
    }

    /**
     * Adds a resource card to the players' deck.
     *
     * @param resource the resource to add
     */
    public void addResource(Config.Resource resource) {
        int count = playerStock.get(resource);
        playerStock.put(resource, count + 1);
    }

    /**
     * Removes a resource card from the players' deck.
     *
     * @param resource the resource to remove
     */
    public void removeResource(Config.Resource resource) {
        int count = playerStock.get(resource);
        if (count > 0) {
            playerStock.put(resource, (count - 1));
        }
    }

    /**
     * Spends the required resources for building.
     *
     * @param resourceList the required resources for building
     */
    public void spendResources(List<Config.Resource> resourceList) {
        for (Config.Resource resource : resourceList) {
            removeResource(resource);
        }
    }

    /**
     * Adds a road to the players' inventory.
     *
     * @param road the roads' location as coordinates
     */
    public void addRoad(Road road) {
        this.roads.add(road);
        this.availableNumberOfRoads--;
    }

    /**
     * Adds a settlement to the players' inventory.
     *
     * @param settlement the players' settlement
     */
    public void addSettlement(Settlement settlement) {
        this.settlements.add(settlement);
        this.availableNumberOfSettlements--;
    }

    /**
     * Converts a settlement to a city in the players' inventory.
     *
     * @param city the settlement to upgrade
     */
    public void upgradeSettlement(Settlement city) {
        Iterator<Settlement> buildingIterator = settlements.iterator();
        boolean settlementFound = false;
        while (!settlementFound && buildingIterator.hasNext()) {
            Settlement settlement = buildingIterator.next();
            if (settlement.getCorner().equals(city.getCorner())) {
                settlements.add(city);
                this.availableNumberOfCities--;
                settlements.remove(city);
                this.availableNumberOfSettlements++;
                settlementFound = true;
            }
        }
    }

    /**
     * Checks if there are more than seven resources in a players' stock.
     *
     * @return true if it's more than seven, else false
     */
    public boolean hasMoreThanSevenResources() {
        int count = 0;
        for (Map.Entry<Config.Resource, Integer> resourceEntry : playerStock.entrySet()) {
            count += resourceEntry.getValue();
        }
        return count > 7;
    }

    public List<Config.Resource> getPlayerResourcesAsArrayList() {
        List<Config.Resource> resourcesAsList = new ArrayList<>();
        for (Map.Entry<Config.Resource, Integer> resourceEntry : playerStock.entrySet()) {
            int countCurrentResource = resourceEntry.getValue();
            while (countCurrentResource > 0) {
                resourcesAsList.add(resourceEntry.getKey());
                countCurrentResource--;
            }
        }
        return resourcesAsList;
    }

    public List<Settlement> getSettlements() {
        return settlements;
    }

    public Config.Faction getFaction() {
        return faction;
    }

    public int getTurnPosition() {
        return turnPosition;
    }

    public Map<Config.Resource, Integer> getPlayerStock() {
        return playerStock;
    }

    public int getResourceCount(Config.Resource resource) {
        return playerStock.get(resource);
    }

    public int getNumberOfRoads() {
        return availableNumberOfRoads;
    }

    public int getNumberOfCities() {
        return availableNumberOfCities;
    }

    public int getNumberOfSettlements() {
        return availableNumberOfSettlements;
    }
}
