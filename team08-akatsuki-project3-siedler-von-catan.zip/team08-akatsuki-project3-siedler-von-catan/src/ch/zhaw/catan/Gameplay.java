package ch.zhaw.catan;


import org.beryx.textio.TextIO;
import org.beryx.textio.TextIoFactory;
import org.beryx.textio.TextTerminal;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

public class Gameplay {

    public static void main(String[] args) {
        new Gameplay().play();
    }

    private final static String STANDARD_CONFIRM = "Press Enter to return to Selection";
    private TextIO textIO = TextIoFactory.getTextIO();
    private TextTerminal<?> textTerminal = textIO.getTextTerminal();
    private SiedlerGame siedlerGame;
    private int playerCount;
    private final static int WIN_POINTS = 5;

    public void play() {
        playerCount = textIO.newIntInputReader().read("How many players? (2-4)");
        while (playerCount <2 || playerCount >4){
            textTerminal.println("invalid input, try again");
            playerCount = textIO.newIntInputReader().read("How many players? (2-4)");
        }

        siedlerGame = new SiedlerGame(WIN_POINTS, playerCount);
        textTerminal.println(siedlerGame.getView().toString());
        while (true) {
            textTerminal.println("Player " + siedlerGame.getCurrentPlayer().getFaction() + " enter coordinates for your initial settlement");
            int xCoordinate = textIO.newIntInputReader().read("x coordinate: ");
            int yCoordinate = textIO.newIntInputReader().read("y coordinate: ");
            boolean valid = siedlerGame.placeInitialSettlement(new Point(xCoordinate, yCoordinate), false);
            if (!valid){textTerminal.println("invalid input, try again");
            continue;}
            siedlerGame.switchToNextPlayer();
            textTerminal.println(siedlerGame.getView().toString());
            if(siedlerGame.getCurrentPlayer().getTurnPosition() == 0){
                siedlerGame.switchToPreviousPlayer();
                break;}
        }

        while (true) {
            textTerminal.println("Player " + siedlerGame.getCurrentPlayer().getFaction() + " enter coordinates for your initial settlement");
            int xCoordinate = textIO.newIntInputReader().read("x coordinate: ");
            int yCoordinate = textIO.newIntInputReader().read("y coordinate: ");
            boolean valid = siedlerGame.placeInitialSettlement(new Point(xCoordinate, yCoordinate), true);
            if (!valid){textTerminal.println("invalid input, try again");
                continue;}
            siedlerGame.switchToPreviousPlayer();
            textTerminal.println(siedlerGame.getView().toString());
            if(siedlerGame.getCurrentPlayer().getTurnPosition() == playerCount-1){
                siedlerGame.switchToNextPlayer();
                break;}
        }
        System.out.println(siedlerGame.getCurrentPlayer().getTurnPosition());
        textTerminal.println(siedlerGame.getView().toString());

        boolean winnerDetected = false;
        while(!winnerDetected) {
            resetBoard();
            winnerDetected = executePlayerTurn();
            siedlerGame.switchToNextPlayer();
        }
        resetBoard();
        Player winner = siedlerGame.getPlayerByFaction(siedlerGame.getWinner());
        textTerminal.println("Congrats! We have a winner!....");
        textTerminal.println("The Winner is " + winner + "!");
        askForConfirmation("We hope you had fun with playing Catan with the cheat sheet! See you next time! press Enter to quit the game...");
        textIO.dispose();
        System.exit(0);
    }

    public void resetBoard() {
        textTerminal.resetToBookmark("clear");
        textTerminal.println(siedlerGame.getView().toString());
    }

    private Point getPointByUserInput(String outputText){
        textTerminal.println(outputText);
        int xCoordinate = getCordinate('X');
        int yCoordinate = getCordinate('Y');
        return new Point(xCoordinate,yCoordinate);
    }

    private Integer getCordinate(char axis) {
        String playername = ConfigHelper.getPlayerTitel(siedlerGame.getCurrentPlayer());
        return textIO.newIntInputReader().read(playername + ", please enter the " + axis +"-Coordinate: ");
    }

    public void placeInitialBuildings() {

    }

    private boolean executePlayerTurn(){
        boolean endTurn = false;
        boolean diceThrown = false;
        boolean winnerDetected = false;
        Player currentPlayer =  siedlerGame.getCurrentPlayer();
        String playerName = ConfigHelper.getPlayerTitel(currentPlayer);

        while(!endTurn && !winnerDetected){
            resetBoard();
            textTerminal.println(playerName + " its your turn. Play wisely!");
            textTerminal.println(playerName + " These are your ressources:" + ConfigHelper.getResourceStockAsString(currentPlayer.getPlayerStock()));
            switch (getEnumValue(Action.class, playerName + ", Choose your Turn")) {
                case THROW_DICE:
                    if (!diceThrown) {
                        executeThrowDice();
                        diceThrown = true;
                    } else {
                        askForConfirmation("\nDice already thrown..." + STANDARD_CONFIRM);
                    }
                    break;
                case BUILD_SETTLEMENT:
                    executeBuildSettlement();
                    winnerDetected = siedlerGame.getWinner() != null;
                    break;
                case BUILD_ROAD:
                    executeBuildRoad();
                    break;
                case BUILD_CITY:
                    executeBuildCity();
                    winnerDetected = siedlerGame.getWinner() != null;
                    break;
                case TRADE_WITH_BANK:
                    executeTradeWithBank();
                    break;
                case END_TURN:
                    endTurn = true;
                    break;
                case QUIT_GAME:
                    executeQuitGame();
                    break;

            }




        }

    return winnerDetected;
    }

    private void executeTradeWithBank() {
        Config.Resource offer = getEnumValue(Config.Resource.class, "Which Resource do you offer?");
        Config.Resource want = getEnumValue(Config.Resource.class, "Which Resource do you want?");
        boolean successful = siedlerGame.tradeWithBankFourToOne(offer, want);
        String output = successful? "Trade was successful!" : "Trade failed!";
        textTerminal.println(output);
        askForConfirmation(STANDARD_CONFIRM);
    }

    private void executeThrowDice(){
        askForConfirmation("Press Enter and throw your two dices!....");
        int diceValue = Dice.rollDice();
        textTerminal.println("\nYou threw a " + diceValue + "!\n");
        if (diceValue == 7){
            executeSevenHasThrown();
        } else {
            siedlerGame.throwDice(diceValue);
            textTerminal.println("Resources have been given to the affected players.");
            askForConfirmation(STANDARD_CONFIRM);
        }
    }

    private void executeSevenHasThrown() {
        siedlerGame.getHalfOfRessources();
        textTerminal.println("Resources for each Player have been cut in half, if they had more than 7 in total!");
        askForConfirmation("\nPress Enter to proceed to Thief-Placement as a 7 was thrown.");
        boolean thiefPlaced = false;
        while (!thiefPlaced){
            resetBoard();
            Point field = getPointByUserInput("Placing Thief...");
            thiefPlaced = siedlerGame.placeThiefAndStealCard(field);
            if (!thiefPlaced) askForConfirmation("Thief-Field not valid! Press Enter to try again");
        }
        textTerminal.println("Thief-Field Valid!");
        textTerminal.println("Thief was placed to a random adjacent Settlement, if there was any.");
        textTerminal.println("Resource was stolen from the Settlement-Owner, if he had any.");
        askForConfirmation(STANDARD_CONFIRM);
    }
    private void executeBuildSettlement() {
        Point settlement = getPointByUserInput("Building Settlement...");
        boolean validBuild = siedlerGame.buildSettlement(settlement);
        String output = validBuild? "Settlement was build successfully!" : "Settlement couldn't be build!";
        textTerminal.println(output);
        askForConfirmation(STANDARD_CONFIRM);
    }
    private void executeBuildRoad() {
        Point roadStartPoint= getPointByUserInput("Select the Start-Corner of your Road:");
        Point roadEndPoint = getPointByUserInput("Select the End-Corner of your Road:");
        boolean validBuild = siedlerGame.buildRoad(roadStartPoint,roadEndPoint);
        String output = validBuild? "Road was build successfully!" : "Road couldn't be build!";
        textTerminal.println(output);
        askForConfirmation(STANDARD_CONFIRM);
    }

    private void executeBuildCity() {
        Point city = getPointByUserInput("Building City...");
        boolean validBuild = siedlerGame.buildCity(city);
        String output = validBuild ? "City was build successfully!" : "City couldn't be build!";
        textTerminal.println(output);
        askForConfirmation(STANDARD_CONFIRM);
    }
        private void executeQuitGame() {
            askForConfirmation("Press Enter to quit this Game!....");
            textIO.dispose();
            System.exit(0);
        }


    private <T extends Enum<T>> T getEnumValue(Class<T> options, String outputText) {
        return textIO.newEnumInputReader(options).read(outputText);
    }

    private void askForConfirmation(String text){
        textTerminal.print(text);
        textTerminal.read(true);
    }









}
