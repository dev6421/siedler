package ch.zhaw.catan;

import java.awt.*;

/**
 * This class creates roads that contains the start and the end as coordinates.

 * @author Akatsuki
 * @version 12.22
 */
public class Road {
    private Config.Faction faction;
    private Point roadStart;
    private Point roadEnd;

    /**
     * Initializes a road.
     *
     * @param roadStart the start of the road as coordinate
     * @param roadEnd the end of the road as coordinate
     */
    public Road(Point roadStart, Point roadEnd, Config.Faction faction) {
        this.roadStart = roadStart;
        this.roadEnd = roadEnd;
        this.faction = faction;
    }

    /**
     * Returns faction of the road.
     *
     * @return faction of the road
     */
    public Config.Faction getFaction() {
        return faction;
    }

    @Override
    public String toString(){
        return faction.toString();
    }
}
