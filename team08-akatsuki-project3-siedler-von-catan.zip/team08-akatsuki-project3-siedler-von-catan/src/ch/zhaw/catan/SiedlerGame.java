package ch.zhaw.catan;

import ch.zhaw.catan.Config.Faction;
import ch.zhaw.catan.Config.Resource;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Collections;
/**
 * This class performs all actions related to modifying the game state. 
 *
 * TODO: (your documentation)
 *
 * @author TODO
 *
 */
public class SiedlerGame {
  static final int FOUR_TO_ONE_TRADE_OFFER = 4;
  static final int FOUR_TO_ONE_TRADE_WANT = 1;

  private SiedlerBoard board;
  private SiedlerBoardTextView view;
  private Player currentPlayer;
  private List<Player> allPlayers = new ArrayList<>();
  private int winPoints;
  private Bank bank;
  private Thief thief;





  
  /**
   * Constructs a SiedlerGame game state object.
   * 
   * @param winPoints the number of points required to win the game
   * @param numberOfPlayers the number of players
   * 
   * @throws IllegalArgumentException if winPoints is lower than 
   *     three or players is not between two and four
   */
  public SiedlerGame(int winPoints, int numberOfPlayers) {
    initPlayers(numberOfPlayers);
    this.board = new SiedlerBoard();
    this.view = new SiedlerBoardTextView(board);
    this.winPoints = winPoints;
    this.bank = new Bank();
    this.thief = new Thief();


  }


  public void initPlayers(int playerCount) {
    for (int i = 0; i < playerCount; i++) {
      Player player = new Player(i);
      allPlayers.add(player);
    }
    this.currentPlayer = allPlayers.get(0);
  }

  /**
   * Switches to the next player in the defined sequence of players.
   */
  public void switchToNextPlayer() {
    int currentPlayerIndex = currentPlayer.getTurnPosition();
    currentPlayerIndex++;
    if (currentPlayerIndex >= allPlayers.size()) {
      currentPlayerIndex = 0;
    }
      currentPlayer = getPlayerByTurnIndex(currentPlayerIndex);

  }

  /**
   * Switches to the previous player in the defined sequence of players.
   */
  public void switchToPreviousPlayer() {
    int currentPlayerIndex = currentPlayer.getTurnPosition();
    currentPlayerIndex--;
    if (currentPlayerIndex < 0) {
      currentPlayerIndex = allPlayers.size() - 1;
    }
      currentPlayer = getPlayerByTurnIndex(currentPlayerIndex);

  }


  public Player getPlayerByTurnIndex(int turnIndex) {
    for (Player p : allPlayers) {
      if (p.getTurnPosition() == turnIndex) {
        return p;
      }
    }
    throw new IllegalArgumentException("turnIndex out of Bounds!");
  }

  /**
   * Return a Player by identifying it's faction.
   * @param faction     The faction as identifier.
   * @return            The Player.
   */
  public Player getPlayerByFaction(Faction faction){
    for (Player p : allPlayers) {
      if (p.getFaction() == faction) return p;
    }
    throw new IllegalArgumentException("Faction not active");
  }

  /**
   * Returns the {@link Faction}s of the active players.
   * 
   * <p>The order of the player's factions in the list must 
   * correspond to the oder in which they play. 
   * Hence, the player that sets the first settlement must be 
   * at position 0 in the list etc. 
   * </p><p>
   * <strong>Important note:</strong> The list must contain the 
   * factions of active players only.</p> 
   * 
   * @return the list with player's factions
   */
  public List<Faction> getPlayerFactions() {
    List<Faction> factions = new ArrayList<>();
    for (Player p : allPlayers) {
      factions.add(p.getFaction());
    }
    return factions;
  }

  
  /**
   * Returns the game board. 
   * 
   * @return the game board
   */
  public SiedlerBoard getBoard() {
    return this.board;
  }

  public SiedlerBoardTextView getView() {
    return this.view;
  }

  /**
   * Returns the {@link Faction} of the current player.
   * 
   * @return the faction of the current player
   */
  public Faction getCurrentPlayerFaction() {
    return currentPlayer.getFaction();
  }

  public Player getCurrentPlayer() {
    return currentPlayer;
  }

  /**
   * Returns how many resource cards of the specified type
   * the current player owns.
   * 
   * @param resource the resource type
   * @return the number of resource cards of this type
   */
  public int getCurrentPlayerResourceStock(Resource resource) {
    return currentPlayer.getResourceCount(resource);
  }

  /**
   * Places a settlement in the founder's phase (phase II) of the game.
   * 
   * <p>The placement does not cost any resource cards. If payout is
   * set to true, for each adjacent resource-producing field, a resource card of the
   * type of the resource produced by the field is taken from the bank (if available) and added to
   * the players' stock of resource cards.</p>
   * 
   * @param position the position of the settlement
   * @param payout if true, the player gets one resource card per adjacent resource-producing field
   * @return true, if the placement was successful
   */
  public boolean placeInitialSettlement(Point position, boolean payout) {
    boolean valid = false;
      if (getBoard().hasCorner(position) &&
              Validation.validNoWater(this.board, position) &&
              Validation.validDistance(this.board, position)) {
        Settlement settlement = new Settlement(getCurrentPlayerFaction(), position);
        getBoard().setCorner(position, settlement);
        currentPlayer.addSettlement(settlement);
        valid = true;
      }
    if (payout) {
      bank.harvestFields(position, getCurrentPlayer(), getBoard());
    }
    return valid;
  }

  /**
   * Places a road in the founder's phase (phase II) of the game.
   * The placement does not cost any resource cards.
   * 
   * @param roadStart position of the start of the road
   * @param roadEnd position of the end of the road
   * @return true, if the placement was successful
   */
  public boolean placeInitialRoad(Point roadStart, Point roadEnd) {
    if (Validation.validRoadPlacement(this.board, roadStart, roadEnd, getCurrentPlayerFaction())) {
      Road road = new Road(roadStart, roadEnd, getCurrentPlayerFaction());
      getBoard().setEdge(roadStart, roadEnd, road);
      currentPlayer.addRoad(road);
      return true;
    }
    return false;
  }

  /**
   * This method takes care of actions depending on the dice throw result.
   * <p>
   * A key action is the payout of the resource cards to the players
   * according to the payout rules of the game. This includes the
   * "negative payout" in case a 7 is thrown and a player has more than
   * {@link Config#MAX_CARDS_IN_HAND_NO_DROP} resource cards.
   * </p><p>
   * If a player does not get resource cards, the list for this players'
   * {@link Faction} is <b>an empty list (not null)</b>!.
   * </p><p>
   * The payout rules of the game take into account factors such as, the number
   * of resource cards currently available in the bank, settlement types
   * (settlement or city), and the number of players that should get resource
   * cards of a certain type (relevant if there are not enough left in the bank).
   * </p>
   *
   * @param dicethrow the resource cards that have been distributed to the players
   * @return the resource cards added to the stock of the different players
   */
  public Map<Faction, List<Resource>> throwDice(int dicethrow) {
    Map<Faction, List<Resource>> allPlayersPayout = new HashMap<>();
    for (Faction faction : getPlayerFactions()) {
      allPlayersPayout.put(faction, new ArrayList<>());
    }
    List<Point> affectedFields = getAffectedFieldsByDiceThrow(dicethrow);
    fillPayout(allPlayersPayout, affectedFields);
    executePayout(allPlayersPayout);
    return allPlayersPayout;
  }

  /**
   * Get affected Fields
   * @param diceThrow   the resource cards that have been distributed to the players
   * @return The affected fields are returned
   */
  private List<Point> getAffectedFieldsByDiceThrow(int diceThrow) {
    List<Point> affectedFields = new ArrayList<>();
    for (Map.Entry <Point, Integer> field : Config.getStandardDiceNumberPlacement().entrySet()) {
      if (field.getValue() == diceThrow) {
        affectedFields.add(field.getKey());
      }
    }
    return affectedFields;
  }

  /**
   * Fill Map with Factions and linked Resources
   *
   * @param allPlayersPayout  Map: Faction & Rescource List
   * @param affectedFields    List of Points
   */
  private void fillPayout(Map<Faction, List<Resource>> allPlayersPayout, List<Point> affectedFields) {
    for (Point field : affectedFields) {
      Resource affectedResource = board.getField(field).getResource();
      List<Settlement> affectedSettlements = board.getCornersOfField(field);
      for (Settlement affectedSettlement : affectedSettlements) {
        if (affectedSettlement instanceof City) {
          allPlayersPayout.get(affectedSettlement.getFaction()).add(affectedResource);
          allPlayersPayout.get(affectedSettlement.getFaction()).add(affectedResource);
        }
        else if (affectedSettlement instanceof Settlement) {
          allPlayersPayout.get(affectedSettlement.getFaction()).add(affectedResource);
        }
      }
    }
  }

  /**
   * Will Payout the Map
   *
   * @param allPlayersPayout  Map: Faction & Rescource List
   */
  private void executePayout(Map<Faction, List<Resource>> allPlayersPayout) {
    for (Map.Entry<Faction, List<Resource>> playerPayout : allPlayersPayout.entrySet()){
      Player affectedPlayer = getPlayerByFaction(playerPayout.getKey());
      for (Resource resource : playerPayout.getValue()){
        if (bank.takeResource(resource))
          affectedPlayer.addResource(resource);
      }
    }
  }

  /**
   * Builds a settlement at the specified position on the board.
   * 
   * <p>The settlement can be built if:
   * <ul>
   * <li> the player possesses the required resource cards</li>
   * <li> a settlement to place on the board</li>
   * <li> the specified position meets the build rules for settlements</li>
   * </ul> 
   * 
   * @param position the position of the settlement
   * @return true, if the placement was successful
   */
  public boolean buildSettlement(Point position) {
    boolean valid = false;
    if (getBoard().hasCorner(position)
        && bank.hasResourcesForBuilding(Config.Structure.SETTLEMENT, currentPlayer)
        && currentPlayer.getNumberOfSettlements() > 0
        && Validation.validNoWater(this.board, position)
        && Validation.validDistance(this.board, position)
        && Validation.validOwnStreet(this.board, getCurrentPlayerFaction(), position)) {
      Settlement settlement = new Settlement(getCurrentPlayerFaction(), position);
      currentPlayer.addSettlement(settlement);
      getBoard().setCorner(position, settlement);
      currentPlayer.spendResources(Config.Structure.SETTLEMENT.getCosts());
      bank.returnResourcesForBuilds(Config.Structure.SETTLEMENT.getCosts());
      valid = true;
    }
    return valid;
  }

  /**
   * Builds a city at the specified position on the board.
   * 
   * <p>The city can be built if:
   * <ul>
   * <li> the player possesses the required resource cards</li>
   * <li> a city to place on the board</li>
   * <li> the specified position meets the build rules for cities</li>
   * </ul> 
   * 
   * @param position the position of the city
   * @return true, if the placement was successful
   */
  public boolean buildCity(Point position) {
    boolean valid = false;
    if (bank.hasResourcesForBuilding(Config.Structure.CITY, currentPlayer)
        && currentPlayer.getNumberOfCities() > 0
        && Validation.validCityPlacement(currentPlayer, position)) {
      Settlement settlement = new City(getCurrentPlayerFaction(), position);
      currentPlayer.upgradeSettlement(settlement);
      getBoard().setCorner(position, settlement);
      currentPlayer.spendResources(Config.Structure.CITY.getCosts());
      bank.returnResourcesForBuilds(Config.Structure.CITY.getCosts());
      valid = true;
    }
    return valid;
  }

  /**
   * Builds a road at the specified position on the board.
   * 
   * <p>The road can be built if:
   * <ul>
   * <li> the player possesses the required resource cards</li>
   * <li> a road to place on the board</li>
   * <li> the specified position meets the build rules for roads</li>
   * </ul> 
   * 
   * @param roadStart the position of the start of the road
   * @param roadEnd the position of the end of the road
   * @return true, if the placement was successful
   */
  public boolean buildRoad(Point roadStart, Point roadEnd) {
    boolean valid = false;
    if (bank.hasResourcesForBuilding(Config.Structure.ROAD, currentPlayer)
        && currentPlayer.getNumberOfRoads() > 0
        && Validation.validRoadPlacement(this.board, roadStart, roadEnd, getCurrentPlayerFaction())) {
      Road road = new Road(roadStart, roadEnd, getCurrentPlayerFaction());
      getBoard().setEdge(roadStart, roadEnd, road);
      currentPlayer.spendResources(Config.Structure.ROAD.getCosts());
      bank.returnResourcesForBuilds(Config.Structure.ROAD.getCosts());
      currentPlayer.addRoad(road);
      valid = true;
    }
    return valid;
  }

  /**
   * <p>Trades in {@link #FOUR_TO_ONE_TRADE_OFFER} resource cards of the
   * offered type for {@link #FOUR_TO_ONE_TRADE_WANT} resource cards of the wanted type.
   * </p><p>
   * The trade only works when bank and player possess the resource cards
   * for the trade before the trade is executed.
   * </p>
   * @param offer offered type
   * @param want wanted type
   * @return true, if the trade was successful
   */
  public boolean tradeWithBankFourToOne(Resource offer, Resource want) {
    boolean tradeSuccess = false;
    if (bank.hasResourcesForTrading(offer,want,currentPlayer)) {
      for (int i = 0; i < Bank.NUMBER_OF_TRADE_CARDS_TO_TAKE;i++) {
        currentPlayer.removeResource(offer);
        bank.returnResource(offer);
      }
      bank.takeResource(want);
      currentPlayer.addResource(want);
      tradeSuccess = true;
    }

    return tradeSuccess;
  }

  /**
   * Returns the winner of the game, if any. 
   * 
   * @return the winner of the game or null, if there is no winner (yet)
   */
  public Faction getWinner() {
    Faction winner = null;
    Map<Player, Integer> winPointsAllPlayer = getWinPointsOfAllPlayer();
    for (Map.Entry<Player, Integer> winPointsForEachPlayer : winPointsAllPlayer.entrySet()){
      if (winPointsForEachPlayer.getValue() >= winPoints)
        winner = winPointsForEachPlayer.getKey().getFaction();
    }
    return winner;
  }

  /**
   * Get all the settlements and Cities of each player.
   * Calculate the Winning Points of each player.
   * @return A Hash Map with all the Winpoints of each player.
   */
  private Map<Player, Integer> getWinPointsOfAllPlayer(){
    Map<Player, Integer> winPoints = new HashMap<>();
    int settlements;
    int cities;

    for (Player player : allPlayers){
      settlements = 0;
      cities = 0;
      for (Settlement settlement : player.getSettlements()){
        if (settlement instanceof City){
          cities++;
        } else {
          settlements++;
        }
      }
      Integer winPointsCount = (2 * cities) + settlements;
      winPoints.put(player, winPointsCount);
    }
    return winPoints;
  }

  public void getHalfOfRessources(){
    for (Player player : allPlayers){
      if (player.hasMoreThanSevenResources()) {
        List<Config.Resource> resourcesAsList = player.getPlayerResourcesAsArrayList();
        Collections.shuffle(resourcesAsList);
        int resourceToRemoveCount = resourcesAsList.size() / 2;
        while (resourceToRemoveCount > 0){
          Resource removedResource = resourcesAsList.remove(0);
          player.removeResource(removedResource);
          bank.returnResource(removedResource);
          resourceToRemoveCount--;
        }
      }
    }
  }
  
  /**
   * Places the thief on the specified field and steals a random resource card (if
   * the player has such cards) from a random player with a settlement at that
   * field (if there is a settlement) and adds it to the resource cards of the
   * current player.
   * 
   * @param field the field on which to place the thief
   * @return false, if the specified field is not a field or the thief cannot be 
   *     placed there (e.g., on water) 
   */
  public boolean placeThiefAndStealCard(Point field) {
  boolean validThiefPlacement = false;
  //validate the thiefplacement if its possible or not.
  if (board.hasField(field) && board.getField(field) != Config.Land.WATER && (!thief.getCenter().equals(field))){
    validThiefPlacement = true;
  }
    // Clears Thief placement
    Annotation oldThiefAnnotation = (Annotation) board.getFieldAnnotation(thief.getCenter(),thief.getCorner());
    oldThiefAnnotation.setValue("");

    thief.setCenter(field);
    List<Settlement> settlements = board.getCornersOfField(field);
    Collections.shuffle(settlements);
    if (!settlements.isEmpty()){
      Point corner = settlements.get(0).getCorner();
      Faction affectedPlayer = settlements.get(0).getFaction();
      thief.setCorner(corner);
      Resource stolenResource = stealPlayersResource(getPlayerByFaction(affectedPlayer));
      if (stolenResource != null){
        currentPlayer.addResource(stolenResource);
        bank.takeResource(stolenResource);
      }
      Annotation thiefAnnotationToPlace = (Annotation) board.getFieldAnnotation(field,corner);
      if (thiefAnnotationToPlace == null){
        board.addFieldAnnotation(field,corner, new Annotation("T"));
      } else {
        thiefAnnotationToPlace.setValue("T");
      }
    }

  return validThiefPlacement;
  }

  private Resource stealPlayersResource(Player player) {
    Resource resource;
    List<Resource> playerResources = player.getPlayerResourcesAsArrayList();
    // Choose a random Building for stealing the resources.
    Collections.shuffle(playerResources);
    resource = (playerResources.get(0) != null)? playerResources.get(0) : null;
    if (resource != null){
      player.removeResource(resource);
      bank.returnResource(resource);
    }
    return resource;
  }

}
