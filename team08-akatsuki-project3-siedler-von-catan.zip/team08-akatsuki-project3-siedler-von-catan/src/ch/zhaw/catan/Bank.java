package ch.zhaw.catan;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class tracks the resource cards of the bank and checks if the player has enough resources for trading and
 * building.
 *
 * @author Akatsuki
 * @version 12.22
 */
public class Bank {
    public static final int NUMBER_OF_TRADE_CARDS_TO_TAKE = 4;
    public static final int NUMBER_OF_TRADE_CARDS_TO_GIVE = 1;
    private Map<Config.Resource, Integer> resourceStock = new HashMap<>(Config.INITIAL_RESOURCE_CARDS_BANK);

    /**
     * Returns a list of resource cards to the bank.
     *
     * @param resourceList the list of resources to return to the bank
     */
    public void returnResourcesForBuilds(List<Config.Resource> resourceList) {
        for (Config.Resource resource : resourceList) {
            returnResource(resource);
        }
    }

    /**
     * Takes a resource card from the bank.
     *
     * @param resource the resource to take from the bank.
     * @return true if possible, else false
     */
    public boolean takeResource(Config.Resource resource) {
        boolean valid;
        Integer count = resourceStock.get(resource);
        if (count <= 0) valid = false;
        else {
            resourceStock.replace(resource, count - 1);
            valid = true;
        }
        return valid;
    }

    /**
     * Returns a resource card to the bank.
     *
     * @param resource the resource to return to the bank.
     */
    public void returnResource(Config.Resource resource) {
        Integer count = resourceStock.get(resource);
        resourceStock.replace(resource, count + 1);
    }

    /**
     * Checks if the player has the required resources to build the requested building.
     *
     * @param structure     the structure to build (road, settlement or city)
     * @param currentPlayer the current player
     * @return true if valid, else false
     */
    public boolean hasResourcesForBuilding(Config.Structure structure, Player currentPlayer) {
        boolean valid = true;
        for (Map.Entry<Config.Resource, Long> resourceEntry : structure.getCostsAsMap().entrySet()) {
            int neededStock = resourceEntry.getValue().intValue();
            int playerStock = currentPlayer.getResourceCount(resourceEntry.getKey());
            if (playerStock < neededStock) valid = false;
        }
        return valid;
    }

    /**
     * Checks if the player has enough resource cards to trade.
     *
     * @param resourcesToTrade  the to-be-traded resource cards
     * @param resourceToRequest the requested resource card
     * @param currentPlayer     the current player
     * @return true if possible, else false
     */
    public boolean hasResourcesForTrading(Config.Resource resourcesToTrade, Config.Resource resourceToRequest, Player currentPlayer) {
        boolean valid = false;
        int playerStock = currentPlayer.getResourceCount(resourcesToTrade);
        int neededStock = resourceStock.get(resourceToRequest);
        if (((playerStock - NUMBER_OF_TRADE_CARDS_TO_TAKE) >= 0) && (neededStock >= NUMBER_OF_TRADE_CARDS_TO_GIVE)) {
            valid = true;
        }
        return valid;
    }

    /**
     * Gathers resource cards from the adjacent fields to the player.
     *
     * @param settlement the position of the settlement
     * @param player     the gathering player
     * @param board      the game board
     * @return true if a field has been harvested, else false
     */
    public boolean harvestFields(Point settlement, Player player, SiedlerBoard board) {
        boolean valid = true;
        List<Config.Land> fields = board.getFields(settlement);
        for (Config.Land field : fields) {
            Config.Resource resource = field.getResource();
            if (resource != null) {
                boolean validCurrentField = this.takeResource(resource);
                if (validCurrentField) {
                    player.addResource(resource);
                } else {
                    valid = false;
                }
            }
        }
        return valid;
    }
}
