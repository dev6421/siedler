package ch.zhaw.catan;

import java.awt.*;

/**
 * This super class is used as the base for the building types settlement and city.
 *
 * @author Akatsuki
 * @version 12.22
 */
public class Settlement {
    private Config.Faction faction;
    private Point corner;

    /**
     * Initializes a settlement.
     *
     * @param faction the players' faction
     * @param corner  the position of the corner
     */
    public Settlement(Config.Faction faction, Point corner) {
        this.faction = faction;
        this.corner = corner;
    }

    public Point getCorner() {
        return corner;
    }

    public Config.Faction getFaction() {
        return faction;
    }

    @Override
    public String toString() {
        return getFaction().toString().toLowerCase();
    }
}
