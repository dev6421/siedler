package ch.zhaw.catan;

import ch.zhaw.hexboard.Label;
import java.util.Random;
import java.util.Random;

/**
 * Class src/ch/zhaw/catan/Dice.java
 * Version:     22.11.2022
 * Authors:     Akatsuki - Gazmend Amiti
 * Description: Class simulates a roll with two dice and returns the number of eyes
 */

public class Dice {
    private static final int MIN_POSSIBLE_EYES = 1;
    private static final int MAX_POSSIBLE_EYES = 6;
    static Random random = new Random();

    public static int rollDice(){
        final int eyes1 = random.nextInt(MIN_POSSIBLE_EYES,MAX_POSSIBLE_EYES+1);
        final int eyes2 = random.nextInt(MIN_POSSIBLE_EYES,MAX_POSSIBLE_EYES+1);
        int total = eyes1 + eyes2;
        return total;
    }

    /**
     * @return the number of eyes possible with two dice (2-12)
     */
    public int getEyes() {
        return rollDice();
    }


    /**
     * Creates a new Label-Object that holds the entered dice number.
     * @param number    Input number to be converted.
     * @return          A Label containing the dice number
     *                  <ul>
     *                  <li>for 0-9: 00-09</li>
     *                  <li>for 10-12: 10-12</li>
     *                  </ul>
     */
    public static Label getDiceNumberAsLabel(Integer number){
        Label label;
        char[] numberAsCharacters = number.toString().toCharArray();
        if (number <= 9){
            label = new Label('0', numberAsCharacters[0]);
        }
        else {
            label = new Label(numberAsCharacters[0], numberAsCharacters[1]);
        }
        return label;
    }
}


