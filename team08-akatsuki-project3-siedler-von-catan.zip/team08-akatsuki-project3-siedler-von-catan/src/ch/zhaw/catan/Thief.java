package ch.zhaw.catan;

import java.awt.*;

public class Thief {
    private Point center;
    private Point corner;

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public Point getCorner() {
        return corner;
    }

    public void setCorner(Point corner) {
        this.corner = corner;
    }
}
