package ch.zhaw.catan;

import ch.zhaw.catan.Config.Land;
import ch.zhaw.hexboard.HexBoardTextView;
import ch.zhaw.hexboard.Label;

import java.awt.*;
import java.util.Map;

public class SiedlerBoardTextView extends HexBoardTextView<Land, String, String, String> {

  public SiedlerBoardTextView(SiedlerBoard board) {
    super(board);
    setDiceNumberOnView();
  }

  /**
   * Adds lower field labels containing Dice Number (from Config class)
   * A conversion from Integer to Label is needed.
   */
  private void setDiceNumberOnView() {
    Map<Point, Integer> lowerfieldlabel = Config.getStandardDiceNumberPlacement();
    for (Map.Entry<Point, Integer> field : lowerfieldlabel.entrySet()){
      super.setLowerFieldLabel(field.getKey(), getDiceToFieldlabel(field.getValue()));
    }
  }

  /**
   * Calls conversion method after validating that the given number is a valid dice throw.
   * @param number    Valid Dice throw number 2-12
   * @return          A Label
   */
  Label getDiceToFieldlabel(Integer number){
    Label output = Dice.getDiceNumberAsLabel(number);
    return output;
  }

}



