package ch.zhaw.catan;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ConfigHelper {

    public static List<Config.Faction> getFactionSequence() {
        List<Config.Faction> factions = new ArrayList<>();
        factions.add(Config.Faction.RED);
        factions.add(Config.Faction.BLUE);
        factions.add(Config.Faction.GREEN);
        factions.add(Config.Faction.YELLOW);
        return factions;
    }


    public static String getResourceReqAsString(Config.Structure structure) {
        String requirementsAsString = "Requirements: ";
        Map<Config.Resource, Long> requirementsMap = structure.getCostsAsMap();
        boolean addComma = false;
        for (Map.Entry<Config.Resource, Long> entry : requirementsMap.entrySet()) {
            if (addComma) {
                requirementsAsString += ", ";
                requirementsAsString += entry.getValue() + "x " + entry.getKey();
                addComma = true;
            }
        }
        return requirementsAsString;
    }

    public static String getResourceStockAsString(Map<Config.Resource, Integer> stock) {
        String stockAsString = "";
        boolean addComma = false;
        for (Map.Entry<Config.Resource, Integer> entry : stock.entrySet()) {
            if (addComma) {
                stockAsString += ", ";
                stockAsString += entry.getValue() + "x " + entry.getKey();
                addComma = true;
            }
        }
        return stockAsString;
    }


    public static String getPlayerTitel(Player player) {
        Config.Faction faction = player.getFaction();
        switch (faction){
            case RED:
                return "RED";
            case BLUE:
                return "BLUE";
            case GREEN:
                return "GREEN";
            case YELLOW:
                return "YELLOW";
            default:
                throw new IllegalArgumentException();
        }
    }

}
