package ch.zhaw.catan;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;


/***
 * TODO Write your own tests in this class.
 * <p>
 * Note:  Have a look at {@link ch.zhaw.catan.games.ThreePlayerStandard}. It can be used
 * to get several different game states.
 * </p>
 */
class SiedlerGameTest {

    @Test
    void dummyTestMethod() {
        fail("Write you own tests in this class.");
    }

}